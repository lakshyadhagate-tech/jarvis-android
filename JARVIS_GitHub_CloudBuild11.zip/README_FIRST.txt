JARVIS Android v1.0 — First working foundation
================================================

For your Samsung Galaxy A26 5G / Android 16. This is an Android Studio source project, not a prebuilt APK.

Included and implemented:
- Futuristic dark-blue JARVIS dashboard.
- Tap-to-talk speech input using Android SpeechRecognizer.
- Spoken replies using Android TextToSpeech.
- Local command handling: greeting, time, date, help, stop speaking.
- Safe app/system handoffs: Android Settings, alarms, camera, calculator (if installed).
- Basic module switchboard UI.

Not implemented yet:
- Always-listening Hey JARVIS wake word.
- AI/cloud reasoning or a full offline language model.
- Autonomous cellular calls, call-audio access, SMS/WhatsApp sending.
- Persistent memory, image generation, PC sync or full module installation system.
The module switches in this first UI are visual prototypes; they do not yet install or activate those features.

BUILD AND INSTALL (Windows 11):
1. Install Android Studio: https://developer.android.com/studio
2. Extract this ZIP to Documents\JARVIS_Android_v1.
3. Open Android Studio > Open > select the extracted folder containing settings.gradle.kts.
4. Wait for Gradle sync. Install Android SDK Platform 35 if prompted. Connect to internet for first dependency download.
5. On your Samsung: Settings > About phone > Software information > tap Build number 7 times.
6. Settings > Developer options > enable USB debugging. Connect phone by USB and accept the debugging prompt.
7. In Android Studio select your phone and press Run ▶.
8. Open JARVIS and grant microphone permission. Tap the microphone and try: "hello Jarvis", "what time is it", "what is today's date", "open settings", "show alarms", "open camera", "open calculator", "help".

Without USB: Android Studio > Build > Build Bundle(s) / APK(s) > Build APK(s). Use the locate link in Build output, transfer app-debug.apk to phone, then install (allow that source if Android asks).

Speech recognition depends on the speech service configured on the phone and may require internet. Android TextToSpeech uses installed voice data. This app does not store call recordings or send a conversation history to a custom server. The selected speech provider may process audio under its own privacy policy.

If Gradle sync/build fails, send me the exact error text or a screenshot and I will guide you through fixing it.
