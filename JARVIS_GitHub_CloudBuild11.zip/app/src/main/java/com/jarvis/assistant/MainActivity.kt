package com.jarvis.assistant

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

private val Navy = Color(0xFF050B18)
private val Panel = Color(0xFF0C1830)
private val Cyan = Color(0xFF36D9FF)
private val Blue = Color(0xFF287BFF)
private val Muted = Color(0xFF9AB2CC)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var ttsReady = false

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) listen() else reply("Microphone permission is needed for voice input.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { JarvisState.message.value = "Listening…" }
                override fun onBeginningOfSpeech() { JarvisState.message.value = "I'm listening." }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { JarvisState.message.value = "Processing…" }
                override fun onError(error: Int) { JarvisState.message.value = "I couldn't hear that clearly. Tap the microphone and try again." }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (words.isNotBlank()) command(words) else reply("I didn't catch that. Please try again.")
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        setContent { MaterialTheme { JarvisHome(::requestMic, ::command, { open(Intent(Settings.ACTION_SETTINGS), "Opening settings.") }) } }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) { tts?.language = Locale.getDefault(); tts?.setSpeechRate(0.94f); tts?.setPitch(0.82f) }
    }

    private fun reply(text: String) {
        JarvisState.message.value = text
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun requestMic() {
        if (recognizer == null) { reply("Speech recognition is not available on this phone."); return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) micPermission.launch(Manifest.permission.RECORD_AUDIO) else listen()
    }

    private fun listen() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        try { recognizer?.startListening(intent) } catch (_: Exception) { reply("I couldn't start voice recognition. Please try again.") }
    }

    private fun command(raw: String) {
        val q = raw.lowercase(Locale.ROOT).trim()
        JarvisState.lastInput.value = raw
        when {
            q.contains("hello") || q.contains("hey jarvis") || q == "hi" -> reply("Hello. JARVIS is online and ready.")
            q.contains("time") -> reply("The time is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()))
            q.contains("date") || q.contains("today") -> reply("Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()))
            q.contains("open settings") || q == "settings" -> open(Intent(Settings.ACTION_SETTINGS), "Opening settings.")
            q.contains("show alarms") || q.contains("open alarm") -> open(Intent(AlarmClock.ACTION_SHOW_ALARMS), "Opening your alarms.")
            q.contains("open camera") || q == "camera" -> open(Intent(MediaStore.ACTION_IMAGE_CAPTURE), "Opening the camera.")
            q.contains("open calculator") || q == "calculator" -> openCalculator()
            q.contains("help") || q.contains("what can you do") -> reply("I can greet you, tell the time and date, open settings, show alarms, open the camera and open the calculator. More features will be added in future modules.")
            q.contains("stop") || q.contains("be quiet") -> { tts?.stop(); JarvisState.message.value = "Speech stopped." }
            else -> reply("I heard: $raw. That command is not in my offline command set yet. The AI connection will be added in a later build.")
        }
    }

    private fun open(intent: Intent, message: String) {
        try { startActivity(intent); reply(message) }
        catch (_: ActivityNotFoundException) { reply("That feature is not available on this phone.") }
        catch (_: SecurityException) { reply("Android blocked that action.") }
    }

    private fun openCalculator() {
        val packages = listOf("com.google.android.calculator", "com.sec.android.app.popupcalculator")
        for (pkg in packages) {
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) { startActivity(launch); reply("Opening calculator."); return }
        }
        reply("I couldn't find an installed calculator app.")
    }

    override fun onDestroy() { recognizer?.destroy(); tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

private object JarvisState {
    val message = mutableStateOf("Systems ready. Tap the microphone to speak.")
    val lastInput = mutableStateOf("No command yet")
}

@Composable
private fun JarvisHome(onMic: () -> Unit, onCommand: (String) -> Unit, onSettings: () -> Unit) {
    var study by remember { mutableStateOf(true) }
    var phone by remember { mutableStateOf(false) }
    var images by remember { mutableStateOf(false) }
    val transition = rememberInfiniteTransition(label = "reactor")
    val glow by transition.animateFloat(0.65f, 1f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "glow")
    Surface(Modifier.fillMaxSize(), color = Navy) {
        Column(Modifier.fillMaxSize().padding(horizontal = 21.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("J.A.R.V.I.S", color = Cyan, fontSize = 25.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("PERSONAL AI SYSTEM", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                }
                Icon(Icons.Default.Settings, "Settings", tint = Cyan, modifier = Modifier.size(26.dp).clickable { onSettings() })
            }
            Spacer(Modifier.height(22.dp))
            Text("YOUR PERSONAL ASSISTANT", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
            Text("How can I help you?", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(12.dp))
            Box(Modifier.size(238.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val c = Offset(size.width / 2, size.height / 2); val r = size.minDimension * .34f
                    drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = .16f * glow), Blue.copy(alpha = .04f), Color.Transparent), c, size.minDimension * .49f), size.minDimension * .49f, c)
                    drawCircle(Cyan.copy(alpha = .24f), r * 1.38f, c, style = Stroke(1.5.dp.toPx()))
                    drawCircle(Blue.copy(alpha = .7f), r * 1.19f, c, style = Stroke(2.dp.toPx()))
                    drawArc(Cyan.copy(alpha = glow), -90f, 286f, false, Offset(c.x-r, c.y-r), androidx.compose.ui.geometry.Size(r*2, r*2), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
                    drawCircle(Color(0xFF102B4A), r, c)
                    drawCircle(Cyan.copy(alpha = .5f), r, c, style = Stroke(1.dp.toPx()))
                    for (i in 0 until 36) { val a = Math.toRadians(i * 10.0); val a1 = r * 1.48f; val a2 = r * if (i % 3 == 0) 1.62f else 1.55f; drawLine(Cyan.copy(alpha = if (i % 3 == 0) .8f else .35f), Offset(c.x + cos(a).toFloat()*a1, c.y + sin(a).toFloat()*a1), Offset(c.x + cos(a).toFloat()*a2, c.y + sin(a).toFloat()*a2), 1.4.dp.toPx()) }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.GraphicEq, null, tint = Cyan, modifier = Modifier.size(42.dp))
                    Text("JARVIS", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("STANDBY", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
                }
            }
            Text(JarvisState.message.value, color = Color(0xFFD8E8F5), fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.heightIn(min = 38.dp))
            Text("LAST INPUT: ${JarvisState.lastInput.value}", color = Muted, fontSize = 9.sp, textAlign = TextAlign.Center, maxLines = 2)
            Spacer(Modifier.height(12.dp))
            Box(Modifier.size(72.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Cyan, Blue))).border(2.dp, Color.White.copy(alpha = .35f), CircleShape).clickable { onMic() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Mic, "Talk to JARVIS", tint = Navy, modifier = Modifier.size(34.dp))
            }
            Text("TAP TO SPEAK", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp, modifier = Modifier.padding(top = 7.dp))
            Spacer(Modifier.height(17.dp))
            Text("QUICK COMMANDS", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, modifier = Modifier.align(Alignment.Start))
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Chip("Time", Modifier.weight(1f)) { onCommand("What time is it?") }
                Chip("Date", Modifier.weight(1f)) { onCommand("What is today's date?") }
                Chip("Help", Modifier.weight(1f)) { onCommand("Help") }
            }
            Spacer(Modifier.height(15.dp))
            Text("MODULE SWITCHBOARD", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, modifier = Modifier.align(Alignment.Start))
            Module("Study assistant", "Foundation module", study) { study = it }
            Module("Phone control", "More actions will be added", phone) { phone = it }
            Module("Image studio", "Integration planned", images) { images = it }
            Spacer(Modifier.weight(1f))
            Text("V1.0 • ANDROID FOUNDATION • TAP-TO-TALK", color = Muted.copy(alpha = .7f), fontSize = 8.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable private fun Chip(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(11.dp)).background(Panel).border(1.dp, Cyan.copy(alpha = .25f), RoundedCornerShape(11.dp)).clickable { onClick() }.padding(vertical = 11.dp), contentAlignment = Alignment.Center) { Text(label, color = Color.White, fontSize = 12.sp) }
}

@Composable private fun Module(name: String, detail: String, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(11.dp)).background(Panel).padding(horizontal = 11.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium); Text(detail, color = Muted, fontSize = 9.sp) }
        Switch(checked = enabled, onCheckedChange = onChange)
    }
}
